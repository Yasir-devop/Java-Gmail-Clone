package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private String[] mailTag = {"Google Maps Timeline                                 11 Nisan","Google Maps Timeline                                 11 Nisan","Google Maps Timeline                                 11 Nisan","Google Maps Timeline                                11 Nisan","Google Photos                                                11 Nisan","Deniz Test                                                   11 Nisan"};
    private String[] mailKonu = {"         Test YK, Mart Ayı Özetiniz","         Test YK, Şubat Ayı Özetiniz","         Test YK, Ocak Ayı Özetiniz","         Test YK, 2020 yılına ait güncellemeler...","         Google Fooğraflar deposu...","         Bu bir test mailidir"};
    private String[] mail = {"         Bu zaman çizelgesi e-postası...","         Bu zaman çizelgesi e-postası...","         Bu zaman çizelgesi e-postası...","         COVID-19 nedeniyle 2020...","         Merhaba Test Oğulcan Deniz İnaç","         izle ve Gör"};
    public ListView mylistview;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mylistview = findViewById(R.id.mylistview);
        mylistview.setAdapter(new BaseAdapter() {
            @Override
            public int getCount() {
                return mailTag.length;
            }

            @Override
            public Object getItem(int position) {
                return null;
            }

            @Override
            public long getItemId(int position) {
                return 0;
            }

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                if (convertView == null){
                    convertView = LayoutInflater.from(getApplicationContext()).inflate(R.layout.items,parent,false);
                }
                TextView textView = convertView.findViewById(R.id.textView);
                textView.setText(mailTag[position]);

                TextView textView2 = convertView.findViewById(R.id.textView2);
                textView2.setText(mailKonu[position]);

                TextView textView3 = convertView.findViewById(R.id.textView3);
                textView3.setText(mail[position]);
                return convertView;
            }
        });
    }
}